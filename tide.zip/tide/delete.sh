aws configure set region us-east-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region us-east-2
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region us-west-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region us-west-2
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE

aws configure set region ap-northeast-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region ap-northeast-2
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region ap-southeast-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region ap-southeast-2
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE

aws configure set region ca-central-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region eu-central-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region eu-west-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE


aws configure set region eu-west-2
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE

aws configure set region sa-east-1
ID_INSTANCE=$(aws ec2 describe-instances --filters "Name=instance-type,Values=t2.micro" --query "Reservations[0].Instances[].InstanceId"| tr -d '"' 2> /dev/null)
aws ec2 terminate-instances --instance-ids $ID_INSTANCE

./ecs.sh
