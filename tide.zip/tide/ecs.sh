aws configure set region us-east-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region us-east-2
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region us-west-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"

aws configure set region us-west-2
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"

aws configure set region ap-south-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region ap-northeast-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region ap-northeast-2
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region ap-southeast-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region ap-southeast-2
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region ca-central-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region eu-central-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region eu-west-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region eu-west-2
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"


aws configure set region sa-east-1
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")

SUBNET=$(aws ec2 describe-subnets --output text --query 'Subnets[0].SubnetId'  2> /dev/null)

aws ecs create-cluster --cluster-name fargate-cluster

aws ecs register-task-definition --cli-input-json file://task1.json

sleep 1m

aws ecs create-service --cluster fargate-cluster --service-name fargate-service \
--task-definition sample-fargate:1 --desired-count 150 --launch-type "FARGATE" \
--network-configuration "awsvpcConfiguration={subnets=[$SUBNET],securityGroups=[$SCGROUP],assignPublicIp=ENABLED}"
