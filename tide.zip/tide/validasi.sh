aws configure set region us-east-1
KEYPAIR=$(aws ec2 create-key-pair --key-name virginia --output text > /root/Downloads/virginia.pem )
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name virginia --security-groups my-ec2)
echo "region us-east-1 ok"

aws configure set region us-east-2
KEYPAIR=$(aws ec2 create-key-pair --key-name ohio --output text > /root/Downloads/ohio.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name ohio --security-groups my-ec2)
echo "region us-east-2 ok"

aws configure set region us-west-1
KEYPAIR=$(aws ec2 create-key-pair --key-name cali --output text > /root/Downloads/cali.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name cali --security-groups my-ec2)
echo "region us-west-1 ok"

aws configure set region us-west-2
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region us-west-2 ok"

aws configure set region ap-northeast-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region ap-northeast-1 ok"


aws configure set region ap-northeast-2
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region ap-northeast-2 ok"


aws configure set region ap-southeast-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region ap-southeast-1 ok"


aws configure set region ap-southeast-2
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region ap-southeast-2 ok"

aws configure set region ca-central-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region ca-central-1 ok"


aws configure set region eu-central-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region eu-central-1 ok"


aws configure set region eu-west-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region eu-west-1 ok"


aws configure set region eu-west-2
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region eu-west-2 ok"

aws configure set region sa-east-1
KEYPAIR=$(aws ec2 create-key-pair --key-name oregon --output text > /root/Downloads/oregon.pem)
SCGROUP=$(aws ec2 create-security-group --group-name my-ec2 --description "my-ec2")
aws ec2 authorize-security-group-ingress --group-name my-ec2 --protocol tcp --port 22 --cidr 0.0.0.0/24
RUIN=$(aws ec2 run-instances --image-id resolve:ssm:/aws/service/ami-amazon-linux-latest/amzn2-ami-hvm-x86_64-gp2 --count 1 --instance-type t2.micro --key-name oregon --security-groups my-ec2)
echo "region sa-east-1 ok"

./create-role.sh
sleep 1m
./delete.sh
