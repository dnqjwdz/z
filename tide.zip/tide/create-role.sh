aws iam create-role --role-name Test-Role --assume-role-policy-document file://test-role.json

aws iam attach-role-policy --role-name Test-Role --policy-arn arn:aws:iam::aws:policy/service-role/AmazonECSTaskExecutionRolePolicy

aws iam put-role-policy --role-name Test-Role --policy-name AmazonSageMakerFullAccess --policy-document file://ecs-policy.json
